package assignment.guess;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.JOptionPane;

public class GuessClient {

	//these are messages to be displayed
	private static final String CORRECT = "Correct � you win!";
	private static final String TOO_HIGH = "Too high � guess again";
	private static final String TOO_LOW = "Too low � guess again";
	private static final String YOU_LOSE = "You�re out of guesses � you lose!";

	// this will change for if server is on a separate machine
	private static final String SERVER_IP = "127.0.0.1";

	private static String CURRENT_STATUS;

	private static int attemptCount = 0;

	public static void main(String[] args) throws IOException {

		do {
			//open connection to server
			Socket socket = new Socket(SERVER_IP, 9090);

			//take the input from user
			String guess = JOptionPane.showInputDialog("Attempt #" + (attemptCount + 1) + " - Guess the number (0-1000):");

			//send the user input to the server
			PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
			out.println(guess);

			//receive server response
			BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			String answer = input.readLine();

			//check server response
			int answerInt = Integer.parseInt(answer);

			if (answerInt > 0) {
				CURRENT_STATUS = TOO_LOW;
			} else if (answerInt == 0) {
				CURRENT_STATUS = CORRECT;
			} else {
				CURRENT_STATUS = TOO_HIGH;
			}

			attemptCount++;

			//display appropriate message
			JOptionPane.showMessageDialog(null, CURRENT_STATUS);

			//check number of attempts
			if (attemptCount >= 10) {
				CURRENT_STATUS = YOU_LOSE;
				JOptionPane.showMessageDialog(null, CURRENT_STATUS);
			}

			// close server connection
			socket.close();

		} while (!(CURRENT_STATUS.equals(CORRECT) || CURRENT_STATUS.equals(YOU_LOSE)));
		
		System.exit(0);
	}

}