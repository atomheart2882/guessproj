package assignment.guess;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class GuessServer {

	private static final int NUMBER = (int) Math.round((Math.random() * 1000));

	public static void main(String[] args) throws IOException {

		System.out.println("number: " + NUMBER);

		ServerSocket listener = new ServerSocket(9090);

		try {

			while (true) {

				Socket socket = listener.accept();
				try {

					//read from client
					BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
					int guess = Integer.parseInt(input.readLine());

					System.out.println("incoming guess: " + guess);

					int response = Integer.compare(NUMBER, guess);
					
					//send response to client
					PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
					out.println(response);
					
					System.out.println("outgoing response: " + response);

				} catch (Exception e) {

					e.printStackTrace();

				} finally {

					socket.close();

				}
			}
		} finally {
			listener.close();
		}

	}

}
